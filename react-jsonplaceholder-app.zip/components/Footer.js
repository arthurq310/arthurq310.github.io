import React from "react";

export default function Footer() {
  return (
    <footer className="bg-slate-800 text-white p-4 text-center">
      <p>Desenvolvido como exercício React - JSONPlaceholder</p>
    </footer>
  );
}
